//# sourceMappingURL=application.js.map
"undefined"!==typeof jQuery&&function(a){a("#spinner").ajaxStart(function(){a(this).fadeIn()}).ajaxStop(function(){a(this).fadeOut()})}(jQuery);